/********************************************************************
 * HFSC Scheduler - Core Implementation
 ********************************************************************/

#include "hfsc_scheduler.h"
#include <rte_malloc.h>
#include <rte_log.h>
#include <rte_memory.h>
#include <string.h>
#include <math.h>

#define RTE_LOGTYPE_HFSC RTE_LOGTYPE_USER1

/* ==================== UTILITY MACROS ==================== */

#define HFSC_LOG(level, fmt, args...) \
    RTE_LOG(level, HFSC, "[HFSC] " fmt, ##args)

#define likely(x)   __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)

#define min(a, b) ((a) < (b) ? (a) : (b))
#define max(a, b) ((a) > (b) ? (a) : (b))

/* 
 * CRITICAL: rte_ring_peek is required for proper next-packet-length lookahead
 * This function was added in DPDK 20.11
 * Attempting to emulate it with dequeue/enqueue creates race conditions
 */
#if RTE_VERSION < RTE_VERSION_NUM(20, 11, 0, 0)
#error "HFSC requires DPDK 20.11 or newer for rte_ring_peek support"
#endif

/**
 * Wraparound-safe time comparisons
 * 
 * TSC counters are 64-bit and can theoretically wrap (though it takes
 * ~195 years at 3 GHz). Use signed arithmetic for safety.
 */
static inline bool
time_after(uint64_t a, uint64_t b)
{
    return (int64_t)(a - b) > 0;
}

static inline bool
time_before(uint64_t a, uint64_t b)
{
    return time_after(b, a);
}

static inline bool
time_after_eq(uint64_t a, uint64_t b)
{
    return (int64_t)(a - b) >= 0;
}

static inline bool
time_before_eq(uint64_t a, uint64_t b)
{
    return time_after_eq(b, a);
}

/* ==================== FIXED-POINT ARITHMETIC ==================== */

/**
 * Convert bytes/sec to bytes/cycle (fixed-point)
 * Result = (rate << HFSC_SM_SHIFT) / tsc_hz
 * 
 * Uses 128-bit arithmetic to prevent overflow for high rates (40+ Gbps)
 */
static inline uint64_t
hfsc_rate_to_sm(uint64_t rate, uint64_t tsc_hz)
{
    if (rate == 0)
        return 0;
    
    /* Use 128-bit arithmetic to avoid overflow and precision loss */
    __uint128_t numerator = (__uint128_t)rate << HFSC_SM_SHIFT;
    uint64_t result = (uint64_t)(numerator / tsc_hz);
    
    /* Ensure minimum value for non-zero rates */
    if (result == 0 && rate > 0) {
        return 1;
    }
    
    return result;
}

/**
 * Convert microseconds to TSC cycles
 */
static inline uint64_t
hfsc_us_to_cycles(uint64_t us, uint64_t tsc_hz)
{
    return (us * tsc_hz) / 1000000ULL;
}

/**
 * Get current time in TSC cycles
 */
static inline uint64_t
hfsc_get_time(void)
{
    return rte_get_tsc_cycles();
}

/* ==================== SERVICE CURVE OPERATIONS ==================== */

/**
 * Compute y given x using the internal service curve
 * 
 * For x <= isc->x: return isc->y
 * For x in (isc->x, isc->x + isc->dx]: 
 *     return isc->y + (x - isc->x) * isc->sm1 >> SHIFT
 * For x > isc->x + isc->dx:
 *     return isc->y + isc->dy + (x - isc->x - isc->dx) * isc->sm2 >> SHIFT
 */
static inline uint64_t
hfsc_sc_x2y(const hfsc_internal_sc_t *isc, uint64_t x)
{
    uint64_t dx, y;
    
    if (x <= isc->x)
        return isc->y;
    
    dx = x - isc->x;
    
    if (dx <= isc->dx) {
        /* First segment */
        y = isc->y + ((dx * isc->sm1) >> HFSC_SM_SHIFT);
    } else {
        /* Second segment */
        y = isc->y + isc->dy + 
            (((dx - isc->dx) * isc->sm2) >> HFSC_SM_SHIFT);
    }
    
    return y;
}

/**
 * Compute x given y using the internal service curve (inverse)
 * 
 * Returns the minimum x such that sc(x) >= y
 */
static inline uint64_t
hfsc_sc_y2x(const hfsc_internal_sc_t *isc, uint64_t y)
{
    uint64_t dy, x;
    
    if (y <= isc->y)
        return isc->x;
    
    dy = y - isc->y;
    
    if (dy <= isc->dy) {
        /* Inverse of first segment */
        if (isc->sm1 == 0)
            return isc->x + isc->dx;
        
        x = isc->x + ((dy << HFSC_SM_SHIFT) / isc->sm1);
    } else {
        /* Inverse of second segment */
        if (isc->sm2 == 0)
            return UINT64_MAX;
        
        x = isc->x + isc->dx + 
            (((dy - isc->dy) << HFSC_SM_SHIFT) / isc->sm2);
    }
    
    return x;
}

/**
 * Initialize internal service curve from spec
 * 
 * This converts the user-specified service curve (m1, d, m2)
 * into the internal representation with fixed-point slopes
 */
static void
hfsc_init_sc(hfsc_internal_sc_t *isc, 
             const hfsc_service_curve_t *sc,
             uint64_t cur_time,
             uint64_t cur_bytes,
             uint64_t tsc_hz)
{
    isc->x = cur_time;
    isc->y = cur_bytes;
    
    if (sc == NULL || (sc->m1 == 0 && sc->m2 == 0)) {
        /* No service curve */
        isc->dx = 0;
        isc->dy = 0;
        isc->sm1 = 0;
        isc->sm2 = 0;
        return;
    }
    
    isc->sm1 = hfsc_rate_to_sm(sc->m1, tsc_hz);
    isc->sm2 = hfsc_rate_to_sm(sc->m2, tsc_hz);
    
    /* dx is the duration of the first segment in cycles */
    isc->dx = hfsc_us_to_cycles(sc->d, tsc_hz);
    
    /* dy is the bytes in the first segment */
    isc->dy = (isc->dx * isc->sm1) >> HFSC_SM_SHIFT;
}

/**
 * Update internal service curve using min operation
 * 
 * Implements Equation (7) from the paper:
 *   D_i(t_k; x) = min [D_i(t_k-1; x), S_i(x - W_i(t_k) + t_k)]
 * 
 * This computes the minimum of two curves:
 * - Old curve: isc (from previous update)
 * - New curve: starts at (cur_time, cur_bytes) with slopes from sc
 * 
 * The min operation ensures that the deadline curve monotonically decreases
 * (becomes more restrictive) as the session receives service.
 * 
 * For CONVEX curves (m1 <= m2):
 *   If old curve is below new curve at cur_time, keep old curve entirely.
 *   Otherwise, use new curve.
 * 
 * For CONCAVE curves (m1 > m2):
 *   Curves may intersect. We find the intersection point and create
 *   a hybrid curve that takes the minimum of both.
 */
static void
hfsc_update_sc(hfsc_internal_sc_t *isc,
               const hfsc_service_curve_t *sc,
               uint64_t cur_time,
               uint64_t cur_bytes,
               uint64_t tsc_hz)
{
    uint64_t sm1, sm2, dx, dy;
    uint64_t y1, y2;
    
    if (sc == NULL || (sc->m1 == 0 && sc->m2 == 0))
        return;
    
    sm1 = hfsc_rate_to_sm(sc->m1, tsc_hz);
    sm2 = hfsc_rate_to_sm(sc->m2, tsc_hz);
    dx = hfsc_us_to_cycles(sc->d, tsc_hz);
    dy = (dx * sm1) >> HFSC_SM_SHIFT;
    
    /* Compute y-values of old curve at key points */
    y1 = hfsc_sc_x2y(isc, cur_time);
    y2 = hfsc_sc_x2y(isc, cur_time + dx);
    
    if (sm1 <= sm2) {
        /* Convex curve */
        if (y1 < cur_bytes) {
            /* Old curve is below new curve at cur_time, keep old */
            return;
        }
        
        /* Use new curve */
        isc->x = cur_time;
        isc->y = cur_bytes;
        isc->dx = dx;
        isc->dy = dy;
        isc->sm1 = sm1;
        isc->sm2 = sm2;
    } else {
        /* Concave curve */
        if (y2 <= cur_bytes + dy) {
            /* Old curve is entirely below new curve, use old */
            return;
        }
        
        /* Curves intersect - compute new intersection point */
        if (y1 > cur_bytes) {
            /* Intersection in first segment */
            uint64_t diff = y1 - cur_bytes;
            uint64_t dsm = sm1 - sm2;
            uint64_t new_dx;
            
            if (dsm == 0) {
                new_dx = dx;
            } else {
                new_dx = (diff << HFSC_SM_SHIFT) / dsm;
                if (new_dx > dx)
                    new_dx = dx;
            }
            
            isc->x = cur_time;
            isc->y = cur_bytes;
            isc->dx = new_dx;
            isc->dy = (new_dx * sm1) >> HFSC_SM_SHIFT;
            isc->sm1 = sm1;
            isc->sm2 = sm2;
        }
    }
}

/**
 * Initialize eligible curve from deadline curve
 * 
 * For convex RSC (m1 <= m2): eligible curve is linear with slope m2
 * For concave RSC (m1 > m2): eligible curve equals deadline curve
 */
static void
hfsc_init_eligible(hfsc_internal_sc_t *el,
                   const hfsc_internal_sc_t *dl,
                   const hfsc_service_curve_t *rsc,
                   uint64_t tsc_hz)
{
    *el = *dl;
    
    if (rsc && rsc->m1 <= rsc->m2) {
        /* Convex - use linear curve with slope m2 */
        el->dx = 0;
        el->dy = 0;
        el->sm1 = hfsc_rate_to_sm(rsc->m2, tsc_hz);
        el->sm2 = el->sm1;
    }
}

/* ==================== HEAP OPERATIONS ==================== */

/**
 * Min-heap for real-time eligible classes (ordered by deadline)
 */

static inline void
heap_swap(hfsc_class_t **heap, int i, int j)
{
    hfsc_class_t *tmp = heap[i];
    heap[i] = heap[j];
    heap[j] = tmp;
    heap[i]->rt_index = i;
    heap[j]->rt_index = j;
}

static void
heap_sift_up(hfsc_class_t **heap, int pos)
{
    while (pos > 0) {
        int parent = (pos - 1) / 2;
        if (heap[pos]->cl_d >= heap[parent]->cl_d)
            break;
        heap_swap(heap, pos, parent);
        pos = parent;
    }
}

static void
heap_sift_down(hfsc_class_t **heap, int size, int pos)
{
    while (1) {
        int left = 2 * pos + 1;
        int right = 2 * pos + 2;
        int smallest = pos;
        
        if (left < size && heap[left]->cl_d < heap[smallest]->cl_d)
            smallest = left;
        if (right < size && heap[right]->cl_d < heap[smallest]->cl_d)
            smallest = right;
        
        if (smallest == pos)
            break;
        
        heap_swap(heap, pos, smallest);
        pos = smallest;
    }
}

static void
heap_insert(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->rt_index >= 0)
        return; /* Already in heap */
    
    if (sched->rt_heap_size >= sched->rt_heap_capacity) {
        HFSC_LOG(ERR, "RT heap full\n");
        return;
    }
    
    cl->rt_index = sched->rt_heap_size;
    sched->rt_heap[sched->rt_heap_size] = cl;
    sched->rt_heap_size++;
    
    heap_sift_up(sched->rt_heap, cl->rt_index);
}

static void
heap_remove(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    int pos = cl->rt_index;
    
    if (pos < 0 || pos >= (int)sched->rt_heap_size)
        return;
    
    sched->rt_heap_size--;
    if (pos == (int)sched->rt_heap_size) {
        cl->rt_index = -1;
        return;
    }
    
    sched->rt_heap[pos] = sched->rt_heap[sched->rt_heap_size];
    sched->rt_heap[pos]->rt_index = pos;
    cl->rt_index = -1;
    
    if (pos > 0 && sched->rt_heap[pos]->cl_d < 
                   sched->rt_heap[(pos - 1) / 2]->cl_d)
        heap_sift_up(sched->rt_heap, pos);
    else
        heap_sift_down(sched->rt_heap, sched->rt_heap_size, pos);
}

static hfsc_class_t *
heap_peek(hfsc_scheduler_t *sched)
{
    if (sched->rt_heap_size == 0)
        return NULL;
    return sched->rt_heap[0];
}

/* ==================== ACTIVATION / DEACTIVATION ==================== */

/**
 * Update virtual time min/max for a hierarchy level
 */
static void
hfsc_update_vt_minmax(hfsc_class_t *parent)
{
    uint64_t vt_min = UINT64_MAX;
    uint64_t vt_max = 0;
    
    for (uint32_t i = 0; i < parent->num_children; i++) {
        hfsc_class_t *child = parent->children[i];
        if (child->state == HFSC_CLASS_ACTIVE) {
            if (child->cl_vt < vt_min)
                vt_min = child->cl_vt;
            if (child->cl_vt > vt_max)
                vt_max = child->cl_vt;
        }
    }
    
    parent->cl_cvtmin = vt_min;
    parent->cl_cvtmax = vt_max;
}

/**
 * Update fit-time min for a hierarchy level (USC enforcement)
 */
static void
hfsc_update_cfmin(hfsc_class_t *parent)
{
    uint64_t cf_min = UINT64_MAX;
    
    for (uint32_t i = 0; i < parent->num_children; i++) {
        hfsc_class_t *child = parent->children[i];
        if (child->state == HFSC_CLASS_ACTIVE) {
            if (child->cl_myf < cf_min)
                cf_min = child->cl_myf;
        }
    }
    
    parent->cl_cfmin = cf_min;
}

/**
 * Activate a class
 * 
 * This is called when the first packet arrives at an empty class.
 * Implements the paper's update_ed() and update_v() functions.
 */
static void
hfsc_activate_class(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    uint64_t cur_time = hfsc_get_time();
    
    if (cl->state == HFSC_CLASS_ACTIVE)
        return;
    
    cl->state = HFSC_CLASS_ACTIVE;
    cl->last_update = cur_time;
    
    /* Initialize/update runtime curves */
    
    /* Real-time service curve (RSC) */
    if (cl->rsc.m1 > 0 || cl->rsc.m2 > 0) {
        hfsc_update_sc(&cl->cl_rsc, &cl->rsc, cur_time, 
                       cl->cumul, sched->tsc_hz);
        hfsc_init_eligible(&cl->cl_eligible, &cl->cl_rsc, 
                          &cl->rsc, sched->tsc_hz);
    }
    
    /* Fair service curve (FSC) */
    if (cl->fsc.m1 > 0 || cl->fsc.m2 > 0) {
        /* Virtual time initialization with period handling */
        if (cl->parent && cl->parent->state == HFSC_CLASS_ACTIVE) {
            /* Inherit parent's virtual time if in same period */
            if (cl->cl_parentperiod != cl->parent->cl_vtperiod) {
                cl->cl_parentperiod = cl->parent->cl_vtperiod;
                
                /* Use parent's minimum VT (more conservative than average) */
                uint64_t parent_vt = cl->parent->cl_cvtmin;
                
                /* Prevent underflow: only add offset if parent VT is ahead */
                if (parent_vt > cl->cl_vt) {
                    cl->cl_vtoff = parent_vt - cl->cl_vt;
                } else {
                    cl->cl_vtoff = 0;
                }
            }
        }
        
        hfsc_update_sc(&cl->cl_fsc, &cl->fsc, cur_time,
                       cl->total, sched->tsc_hz);
        cl->cl_vt = hfsc_sc_y2x(&cl->cl_fsc, cl->total);
        cl->cl_vt += cl->cl_vtoff; /* Apply period offset */
    }
    
    /* Upper-limit service curve (USC) */
    if (cl->usc.m1 > 0 || cl->usc.m2 > 0) {
        hfsc_update_sc(&cl->cl_usc, &cl->usc, cur_time,
                       cl->total, sched->tsc_hz);
        cl->cl_myf = hfsc_sc_y2x(&cl->cl_usc, cl->total);
    } else {
        cl->cl_myf = UINT64_MAX;
    }
    
    cl->cl_vtperiod++;
    cl->in_vttree = true;
    
    /* Update parent's min/max tracking */
    if (cl->parent) {
        hfsc_update_vt_minmax(cl->parent);
        hfsc_update_cfmin(cl->parent);
        
        /* Recursively activate parent */
        hfsc_activate_class(sched, cl->parent);
    }
}

/**
 * Deactivate a class
 * 
 * This is called when a class queue becomes empty.
 */
static void
hfsc_deactivate_class(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->state != HFSC_CLASS_ACTIVE)
        return;
    
    /* Remove from RT heap if present */
    if (cl->rt_index >= 0)
        heap_remove(sched, cl);
    
    cl->state = HFSC_CLASS_INACTIVE;
    cl->in_vttree = false;
    
    /* Update parent's min/max tracking */
    if (cl->parent) {
        hfsc_update_vt_minmax(cl->parent);
        hfsc_update_cfmin(cl->parent);
        
        /* Check if parent should be deactivated */
        bool has_active_child = false;
        for (uint32_t i = 0; i < cl->parent->num_children; i++) {
            if (cl->parent->children[i]->state == HFSC_CLASS_ACTIVE) {
                has_active_child = true;
                break;
            }
        }
        
        if (!has_active_child)
            hfsc_deactivate_class(sched, cl->parent);
    }
}

/**
 * Update eligible time and deadline after packet dequeue
 */
static void
hfsc_update_ed(hfsc_scheduler_t *sched, hfsc_class_t *cl, uint32_t len)
{
    uint64_t cur_time = hfsc_get_time();
    
    if (cl->qlen == 0) {
        /* No more packets - remove from RT heap */
        if (cl->rt_index >= 0)
            heap_remove(sched, cl);
        return;
    }
    
    if (cl->rsc.m1 == 0 && cl->rsc.m2 == 0)
        return;
    
    /* Get next packet length (peek) */
    struct rte_mbuf *next;
    if (rte_ring_peek(cl->queue, (void **)&next) == 0) {
        len = rte_pktmbuf_pkt_len(next);
    } else {
        len = 1500; /* Fallback */
    }
    
    /* Update eligible time and deadline */
    cl->cl_e = hfsc_sc_y2x(&cl->cl_eligible, cl->cumul);
    cl->cl_d = hfsc_sc_y2x(&cl->cl_rsc, cl->cumul + len);
    
    /* Update position in RT heap */
    if (cl->rt_index >= 0) {
        int old_idx = cl->rt_index;
        if (old_idx > 0 && 
            cl->cl_d < sched->rt_heap[(old_idx - 1) / 2]->cl_d) {
            heap_sift_up(sched->rt_heap, old_idx);
        } else {
            heap_sift_down(sched->rt_heap, sched->rt_heap_size, old_idx);
        }
    }
}

/**
 * Update virtual time after packet dequeue
 */
static void
hfsc_update_vt(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    uint64_t cur_time = hfsc_get_time();
    hfsc_class_t *p;
    
    if (cl->fsc.m1 == 0 && cl->fsc.m2 == 0)
        return;
    
    /* Update this class's virtual time */
    cl->cl_vt = hfsc_sc_y2x(&cl->cl_fsc, cl->total);
    cl->cl_vt += cl->cl_vtoff;
    
    /* Propagate virtual time changes up the hierarchy */
    for (p = cl->parent; p != NULL; p = p->parent) {
        if (p->state != HFSC_CLASS_ACTIVE)
            break;
        
        hfsc_update_vt_minmax(p);
        
        /* Update parent's own virtual time if it has FSC */
        if (p->fsc.m1 > 0 || p->fsc.m2 > 0) {
            uint64_t old_vt = p->cl_vt;
            p->cl_vt = hfsc_sc_y2x(&p->cl_fsc, p->total);
            p->cl_vt += p->cl_vtoff;
        }
    }
}

/**
 * Update USC fit-time after packet dequeue
 */
static void
hfsc_update_usc(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->usc.m1 == 0 && cl->usc.m2 == 0) {
        cl->cl_myf = UINT64_MAX;
        return;
    }
    
    cl->cl_myf = hfsc_sc_y2x(&cl->cl_usc, cl->total);
    
    /* Update parent's cfmin */
    if (cl->parent) {
        hfsc_update_cfmin(cl->parent);
        
        /* Propagate up */
        for (hfsc_class_t *p = cl->parent; p != NULL; p = p->parent) {
            if (p->state != HFSC_CLASS_ACTIVE)
                break;
            hfsc_update_cfmin(p);
        }
    }
}

/* ==================== PACKET SELECTION ==================== */

/**
 * Real-time criterion selection
 * 
 * Select eligible class with earliest deadline.
 * When multiple classes have the same deadline, round-robin among them
 * to prevent starvation.
 * 
 * Paper: Section III, "real-time criterion"
 */
static hfsc_class_t *
hfsc_select_rt(hfsc_scheduler_t *sched)
{
    hfsc_class_t *cl;
    hfsc_class_t *candidates[HFSC_MAX_CLASSES];
    uint32_t num_candidates = 0;
    uint64_t cur_time = hfsc_get_time();
    uint64_t min_deadline = UINT64_MAX;
    
    /* 
     * CRITICAL FIX: Don't just use heap[0]!
     * When multiple classes have identical RSC curves, they have the same deadline.
     * Heap always returns the same one, starving others.
     * 
     * Solution: Scan heap for all classes with minimum deadline, then round-robin.
     */
    
    /* Find minimum deadline among eligible classes */
    for (uint32_t i = 0; i < sched->rt_heap_size; i++) {
        cl = sched->rt_heap[i];
        
        /* Skip if not eligible */
        if (time_after(cl->cl_e, cur_time))
            continue;
        
        /* Skip if USC blocked */
        if (time_after(cl->cl_myf, cur_time))
            continue;
        
        /* Check parent USC constraints */
        bool parent_blocked = false;
        for (hfsc_class_t *p = cl->parent; p != NULL; p = p->parent) {
            if (time_after(p->cl_myf, cur_time)) {
                parent_blocked = true;
                break;
            }
        }
        if (parent_blocked)
            continue;
        
        /* Update minimum deadline */
        if (cl->cl_d < min_deadline) {
            min_deadline = cl->cl_d;
        }
    }
    
    if (min_deadline == UINT64_MAX)
        return NULL;  /* No eligible classes */
    
    /* Collect all classes with minimum deadline */
    for (uint32_t i = 0; i < sched->rt_heap_size; i++) {
        cl = sched->rt_heap[i];
        
        if (cl->cl_d != min_deadline)
            continue;
        
        /* Re-check eligibility (redundant but safe) */
        if (time_after(cl->cl_e, cur_time))
            continue;
        if (time_after(cl->cl_myf, cur_time))
            continue;
        
        candidates[num_candidates++] = cl;
    }
    
    if (num_candidates == 0)
        return NULL;
    
    if (num_candidates == 1)
        return candidates[0];
    
    /* 
     * Multiple classes with same deadline - use round-robin
     * This prevents starvation when classes have identical RSC curves
     */
    static uint32_t rr_counter = 0;
    uint32_t idx = (rr_counter++) % num_candidates;
    
    return candidates[idx];
}

/**
 * Link-sharing criterion selection
 * 
 * Recursively select class with minimum virtual time.
 * Paper: Section III, "link-sharing criterion"
 */
static hfsc_class_t *
hfsc_select_ls(hfsc_scheduler_t *sched, hfsc_class_t *p)
{
    hfsc_class_t *cl, *best;
    uint64_t cur_time = hfsc_get_time();
    uint64_t min_vt;
    
    if (p->state != HFSC_CLASS_ACTIVE)
        return NULL;
    
    /* USC check for this level */
    if (time_after(p->cl_myf, cur_time))
        return NULL;
    
    if (p->is_leaf)
        return p;
    
    /* Find child with minimum virtual time */
    best = NULL;
    min_vt = UINT64_MAX;
    
    for (uint32_t i = 0; i < p->num_children; i++) {
        cl = p->children[i];
        
        if (cl->state != HFSC_CLASS_ACTIVE)
            continue;
        
        /* USC enforcement at child level */
        if (time_after(cl->cl_myf, cur_time))
            continue;
        
        if (cl->cl_vt < min_vt) {
            min_vt = cl->cl_vt;
            best = cl;
        }
    }
    
    if (best == NULL)
        return NULL;
    
    /* Recurse to find leaf */
    return hfsc_select_ls(sched, best);
}

/* ==================== PUBLIC API ==================== */

int
hfsc_init(hfsc_scheduler_t **sched_out)
{
    hfsc_scheduler_t *sched;
    
    sched = rte_zmalloc("hfsc_sched", sizeof(*sched), RTE_CACHE_LINE_SIZE);
    if (sched == NULL) {
        HFSC_LOG(ERR, "Failed to allocate scheduler\n");
        return -1;
    }
    
    /* Allocate RT heap */
    sched->rt_heap_capacity = HFSC_MAX_CLASSES;
    sched->rt_heap = rte_zmalloc("hfsc_heap", 
                                 sizeof(hfsc_class_t *) * sched->rt_heap_capacity,
                                 RTE_CACHE_LINE_SIZE);
    if (sched->rt_heap == NULL) {
        HFSC_LOG(ERR, "Failed to allocate RT heap\n");
        rte_free(sched);
        return -1;
    }
    
    sched->tsc_hz = rte_get_tsc_hz();
    
    HFSC_LOG(INFO, "HFSC scheduler initialized (TSC=%lu Hz)\n", 
             sched->tsc_hz);
    
    *sched_out = sched;
    return 0;
}

void
hfsc_cleanup(hfsc_scheduler_t *sched)
{
    if (sched == NULL)
        return;
    
    /* Free all classes */
    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->classes[i];
        if (cl) {
            if (cl->queue) {
                /* Drain queue */
                struct rte_mbuf *m;
                while (rte_ring_dequeue(cl->queue, (void **)&m) == 0) {
                    rte_pktmbuf_free(m);
                }
                rte_ring_free(cl->queue);
            }
            rte_free(cl);
        }
    }
    
    rte_free(sched->rt_heap);
    rte_free(sched);
    
    HFSC_LOG(INFO, "HFSC scheduler cleaned up\n");
}

hfsc_class_t *
hfsc_create_root(hfsc_scheduler_t *sched,
                 const hfsc_service_curve_t *rsc,
                 const hfsc_service_curve_t *fsc,
                 const hfsc_service_curve_t *usc)
{
    if (sched->root != NULL) {
        HFSC_LOG(ERR, "Root class already exists\n");
        return NULL;
    }
    
    return hfsc_create_class(sched, NULL, 0, false, rsc, fsc, usc);
}

hfsc_class_t *
hfsc_create_class(hfsc_scheduler_t *sched,
                  hfsc_class_t *parent,
                  uint32_t class_id,
                  bool is_leaf,
                  const hfsc_service_curve_t *rsc,
                  const hfsc_service_curve_t *fsc,
                  const hfsc_service_curve_t *usc)
{
    hfsc_class_t *cl;
    char name[64];
    
    if (sched->num_classes >= HFSC_MAX_CLASSES) {
        HFSC_LOG(ERR, "Maximum number of classes reached\n");
        return NULL;
    }
    
    /* === ADMISSION CONTROL === */
    
    /* FSC is required and must have positive bandwidth */
    if (fsc == NULL || fsc->m2 == 0) {
        HFSC_LOG(ERR, "FSC is required and m2 must be > 0\n");
        return NULL;
    }
    
    /* Validate FSC parameters */
    if (fsc->m1 < 0 || fsc->m2 < 0 || fsc->d < 0) {
        HFSC_LOG(ERR, "FSC parameters must be non-negative\n");
        return NULL;
    }
    
    /* Validate RSC if provided */
    if (rsc && (rsc->m1 < 0 || rsc->m2 < 0 || rsc->d < 0)) {
        HFSC_LOG(ERR, "RSC parameters must be non-negative\n");
        return NULL;
    }
    
    /* USC must be >= FSC if both specified */
    if (usc) {
        if (usc->m1 < 0 || usc->m2 < 0 || usc->d < 0) {
            HFSC_LOG(ERR, "USC parameters must be non-negative\n");
            return NULL;
        }
        
        /* Check that USC >= FSC in long term */
        if (usc->m2 < fsc->m2) {
            HFSC_LOG(ERR, "USC m2 (%lu) must be >= FSC m2 (%lu)\n",
                     usc->m2, fsc->m2);
            return NULL;
        }
    }
    
    /* Check parent capacity - sum of children FSC should not exceed parent FSC */
    if (parent && !parent->is_leaf) {
        uint64_t sibling_sum = 0;
        for (uint32_t i = 0; i < parent->num_children; i++) {
            sibling_sum += parent->children[i]->fsc.m2;
        }
        
        if (sibling_sum + fsc->m2 > parent->fsc.m2) {
            HFSC_LOG(ERR, "Class %u: Exceeds parent capacity\n", class_id);
            HFSC_LOG(ERR, "  Siblings use: %lu bytes/sec\n", sibling_sum);
            HFSC_LOG(ERR, "  This class:   %lu bytes/sec\n", fsc->m2);
            HFSC_LOG(ERR, "  Parent has:   %lu bytes/sec\n", parent->fsc.m2);
            HFSC_LOG(ERR, "  Oversubscription: %lu bytes/sec\n",
                     sibling_sum + fsc->m2 - parent->fsc.m2);
            return NULL;
        }
    }
    
    /* === END ADMISSION CONTROL === */
    
    cl = rte_zmalloc("hfsc_class", sizeof(*cl), RTE_CACHE_LINE_SIZE);
    if (cl == NULL) {
        HFSC_LOG(ERR, "Failed to allocate class\n");
        return NULL;
    }
    
    cl->class_id = class_id;
    cl->parent = parent;
    cl->is_leaf = is_leaf;
    cl->state = HFSC_CLASS_INACTIVE;
    cl->rt_index = -1;
    
    /* Copy service curves */
    if (rsc)
        cl->rsc = *rsc;
    cl->fsc = *fsc;  /* FSC is required */
    if (usc)
        cl->usc = *usc;
    
    cl->cl_myf = UINT64_MAX;
    cl->cl_cfmin = UINT64_MAX;
    cl->cl_cvtmin = UINT64_MAX;
    
    /* Create queue for leaf classes */
    if (is_leaf) {
        snprintf(name, sizeof(name), "hfsc_q_%u", class_id);
        cl->queue = rte_ring_create(name, HFSC_QUEUE_SIZE, 
                                     rte_socket_id(),
                                     RING_F_SP_ENQ | RING_F_SC_DEQ);
        if (cl->queue == NULL) {
            HFSC_LOG(ERR, "Failed to create queue for class %u\n", class_id);
            rte_free(cl);
            return NULL;
        }
    }
    
    /* Add to parent's children */
    if (parent) {
        if (parent->num_children >= HFSC_MAX_CHILDREN) {
            HFSC_LOG(ERR, "Parent has too many children\n");
            if (cl->queue)
                rte_ring_free(cl->queue);
            rte_free(cl);
            return NULL;
        }
        parent->children[parent->num_children++] = cl;
    } else {
        sched->root = cl;
    }
    
    sched->classes[sched->num_classes++] = cl;
    
    HFSC_LOG(INFO, "Created %s class %u (RSC: %lu/%lu/%lu, FSC: %lu/%lu/%lu)\n",
             is_leaf ? "leaf" : "interior", class_id,
             cl->rsc.m1, cl->rsc.d, cl->rsc.m2,
             cl->fsc.m1, cl->fsc.d, cl->fsc.m2);
    
    return cl;
}

int
hfsc_enqueue(hfsc_scheduler_t *sched, hfsc_class_t *cl, struct rte_mbuf *m)
{
    uint32_t len;
    
    if (!cl->is_leaf) {
        HFSC_LOG(ERR, "Cannot enqueue to non-leaf class\n");
        return -1;
    }
    
    if (rte_ring_full(cl->queue)) {
        cl->stats_drops++;
        sched->total_drops++;
        return -1;
    }
    
    len = rte_pktmbuf_pkt_len(m);
    
    /* Activate class if needed */
    if (cl->state == HFSC_CLASS_INACTIVE)
        hfsc_activate_class(sched, cl);
    
    /* Enqueue packet */
    if (rte_ring_enqueue(cl->queue, m) < 0) {
        cl->stats_drops++;
        sched->total_drops++;
        return -1;
    }
    
    cl->qlen++;
    cl->qbytes += len;
    sched->total_packets_in++;
    
    /* If this is the first packet and RSC is defined, add to RT heap */
    if (cl->qlen == 1 && (cl->rsc.m1 > 0 || cl->rsc.m2 > 0)) {
        /* Compute eligible time and deadline */
        cl->cl_e = hfsc_sc_y2x(&cl->cl_eligible, cl->cumul);
        cl->cl_d = hfsc_sc_y2x(&cl->cl_rsc, cl->cumul + len);
        heap_insert(sched, cl);
    }
    
    return 0;
}

struct rte_mbuf *
hfsc_dequeue(hfsc_scheduler_t *sched)
{
    hfsc_class_t *cl;
    struct rte_mbuf *m;
    uint32_t len;
    uint64_t cur_time;
    bool selected_by_rt = false;
    
    if (sched->root == NULL || sched->root->state != HFSC_CLASS_ACTIVE)
        return NULL;
    
    cur_time = hfsc_get_time();
    
    /* Try real-time criterion first */
    cl = hfsc_select_rt(sched);
    if (cl != NULL) {
        selected_by_rt = true;
    } else {
        /* Fall back to link-sharing criterion */
        cl = hfsc_select_ls(sched, sched->root);
    }
    
    if (cl == NULL || !cl->is_leaf)
        return NULL;
    
    /* Dequeue packet */
    if (rte_ring_dequeue(cl->queue, (void **)&m) < 0)
        return NULL;
    
    len = rte_pktmbuf_pkt_len(m);
    
    /* Defensive check - this should never happen */
    if (unlikely(cl->qlen == 0)) {
        HFSC_LOG(WARNING, "Dequeued from class %u with qlen=0\n", cl->class_id);
        cl->qlen = 1;  /* Fix the inconsistency */
    }
    
    /* Update accounting */
    cl->qlen--;
    cl->qbytes -= len;
    cl->total += len;
    cl->stats_packets++;
    cl->stats_bytes += len;
    sched->total_packets_out++;
    
    /* Update cumul ONLY if selected by RT criterion */
    if (selected_by_rt) {
        cl->cumul += len;
    }
    
    /* Update curves */
    cur_time = hfsc_get_time();
    
    if (cl->rsc.m1 > 0 || cl->rsc.m2 > 0) {
        hfsc_update_sc(&cl->cl_rsc, &cl->rsc, cur_time,
                       cl->cumul, sched->tsc_hz);
        hfsc_init_eligible(&cl->cl_eligible, &cl->cl_rsc,
                          &cl->rsc, sched->tsc_hz);
        hfsc_update_ed(sched, cl, len);
    }
    
    if (cl->fsc.m1 > 0 || cl->fsc.m2 > 0) {
        hfsc_update_sc(&cl->cl_fsc, &cl->fsc, cur_time,
                       cl->total, sched->tsc_hz);
        hfsc_update_vt(sched, cl);
    }
    
    if (cl->usc.m1 > 0 || cl->usc.m2 > 0) {
        hfsc_update_sc(&cl->cl_usc, &cl->usc, cur_time,
                       cl->total, sched->tsc_hz);
        hfsc_update_usc(sched, cl);
    }
    
    /* Update parent totals up the hierarchy */
    for (hfsc_class_t *p = cl->parent; p != NULL; p = p->parent) {
        p->total += len;
        
        /* Update parent cumul if RT criterion was used */
        if (selected_by_rt) {
            p->cumul += len;
        }
        
        /* Update parent's FSC and USC curves */
        if (p->fsc.m1 > 0 || p->fsc.m2 > 0) {
            hfsc_update_sc(&p->cl_fsc, &p->fsc, cur_time,
                          p->total, sched->tsc_hz);
        }
        if (p->usc.m1 > 0 || p->usc.m2 > 0) {
            hfsc_update_sc(&p->cl_usc, &p->usc, cur_time,
                          p->total, sched->tsc_hz);
            p->cl_myf = hfsc_sc_y2x(&p->cl_usc, p->total);
        }
    }
    
    /* Deactivate if queue empty */
    if (cl->qlen == 0) {
        hfsc_deactivate_class(sched, cl);
        cl->cl_vtperiod++;
    }
    
    return m;
}

bool
hfsc_has_packets(hfsc_scheduler_t *sched)
{
    return (sched->root != NULL && sched->root->state == HFSC_CLASS_ACTIVE);
}

void
hfsc_get_class_stats(hfsc_class_t *cl,
                     uint64_t *packets,
                     uint64_t *bytes,
                     uint64_t *drops)
{
    if (packets)
        *packets = cl->stats_packets;
    if (bytes)
        *bytes = cl->stats_bytes;
    if (drops)
        *drops = cl->stats_drops;
}

void
hfsc_dump_state(hfsc_scheduler_t *sched)
{
    HFSC_LOG(INFO, "=== HFSC State ===\n");
    HFSC_LOG(INFO, "Total classes: %u\n", sched->num_classes);
    HFSC_LOG(INFO, "RT heap size: %u\n", sched->rt_heap_size);
    HFSC_LOG(INFO, "Packets in: %lu, out: %lu, drops: %lu\n",
             sched->total_packets_in, sched->total_packets_out,
             sched->total_drops);
    
    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->classes[i];
        HFSC_LOG(INFO, "  Class %u: %s, qlen=%u, total=%lu, cumul=%lu, "
                 "vt=%lu, state=%s\n",
                 cl->class_id, cl->is_leaf ? "LEAF" : "INT",
                 cl->qlen, cl->total, cl->cumul, cl->cl_vt,
                 cl->state == HFSC_CLASS_ACTIVE ? "ACTIVE" : "INACTIVE");
    }
}
