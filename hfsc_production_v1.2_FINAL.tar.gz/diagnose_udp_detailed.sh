#!/bin/bash
#############################################################################
# HFSC UDP Traffic Diagnostic - For (udp1, udp2) Issue
#
# Diagnoses why udp1+udp2 only gets 16 Mbps instead of 32 Mbps
#############################################################################

echo "=========================================================================="
echo "HFSC UDP Traffic Issue Diagnostic"
echo "=========================================================================="
echo ""

echo "SCENARIO:"
echo "  - Sending traffic to port 5001 → udp1_class (under site1)"
echo "  - Sending traffic to port 6001 → udp2_class (under site2)"
echo "  - Expected: 32 Mbps total (16 Mbps each)"
echo "  - Actual: 16 Mbps total, one class starving"
echo ""

echo "QUESTION 1: How are you sending traffic?"
echo "  a) One iperf3 to port 5001 + Another iperf3 to port 6001"
echo "  b) Single iperf3 to both ports somehow"
echo "  c) Modified classification to return both classes for same port"
echo ""
read -p "Your answer (a/b/c): " answer1

if [ "$answer1" = "c" ]; then
    echo ""
    echo "⚠️  ISSUE IDENTIFIED!"
    echo ""
    echo "You CANNOT return multiple classes from classify_packet()!"
    echo "Each packet goes to ONE class only."
    echo ""
    echo "If you're trying to test like this:"
    echo ""
    echo "  if (dst_port == 5001)"
    echo "      return udp1_class;  // First half of packets"
    echo "  if (dst_port == 5001)   // DUPLICATE CHECK!"
    echo "      return udp2_class;  // Never reached!"
    echo ""
    echo "FIX: Use DIFFERENT ports for different classes:"
    echo ""
    echo "  # Terminal 1:"
    echo "  iperf3 -c <ip> -u -b 20M -p 5001  # → udp1"
    echo ""
    echo "  # Terminal 2:"
    echo "  iperf3 -c <ip> -u -b 20M -p 6001  # → udp2"
    echo ""
    exit 0
fi

echo ""
echo "QUESTION 2: What does 'sometimes udp1, sometimes udp2' mean?"
echo "  a) Between different test runs, different class wins"
echo "  b) Within same run, it switches back and forth"
echo "  c) Depends on which iperf3 you start first"
echo ""
read -p "Your answer (a/b/c): " answer2

if [ "$answer2" = "c" ]; then
    echo ""
    echo "⚠️  ISSUE IDENTIFIED: Race Condition on Startup"
    echo ""
    echo "Whichever class becomes active FIRST 'wins' and blocks the other."
    echo "This happens because:"
    echo ""
    echo "1. First iperf3 starts → class becomes active"
    echo "2. That class starts consuming bandwidth"
    echo "3. Parent USC (site1 or site2) advances based on first class"
    echo "4. When second iperf3 starts, parent already has high cl_myf"
    echo "5. Second class gets blocked by parent USC!"
    echo ""
    echo "This is a BUG in the USC enforcement logic."
    echo ""
fi

if [ "$answer2" = "a" ]; then
    echo ""
    echo "✓ This confirms the race condition issue."
    echo ""
    echo "The class that becomes active first blocks the other via parent USC."
    echo ""
fi

echo ""
echo "QUESTION 3: Are udp1 and udp2 under the SAME parent or DIFFERENT?"
echo ""
echo "From hfsc_example.c:"
echo "  udp1 → site1 → root"
echo "  udp2 → site2 → root"
echo ""
echo "So they're under DIFFERENT parents (site1 vs site2)."
echo ""
read -p "Is this correct in your setup? (yes/no): " answer3

if [ "$answer3" != "yes" ]; then
    echo ""
    echo "⚠️  SETUP ISSUE!"
    echo ""
    echo "If you modified the code and put BOTH under same parent (site1),"
    echo "then they would compete for site1's 60 Mbps USC."
    echo ""
    echo "But 16 + 16 = 32 Mbps < 60 Mbps, so this should still work."
    echo ""
    echo "Check your setup_hfsc_hierarchy() function!"
    exit 0
fi

echo ""
echo "QUESTION 4: Check the statistics output. Which class shows drops?"
echo "  a) udp1 has drops, udp2 has 0 packets"
echo "  b) udp2 has drops, udp1 has 0 packets"
echo "  c) Both have some packets but one has drops"
echo "  d) One has packets, other has 0 (no drops on either)"
echo ""
read -p "Your answer (a/b/c/d): " answer4

if [ "$answer4" = "d" ]; then
    echo ""
    echo "⚠️  CRITICAL: Classification Bug!"
    echo ""
    echo "If one class has 0 packets (not even drops), then packets"
    echo "are NOT being classified to that class at all!"
    echo ""
    echo "This means your classify_packet() is NOT returning the"
    echo "expected class for port 6001 (or 5001)."
    echo ""
    echo "Add debug output to classify_packet():"
    echo ""
    cat << 'EOF'
static hfsc_class_t *
classify_packet(struct rte_mbuf *m)
{
    // ... existing code to extract dst_port ...
    
    hfsc_class_t *result = NULL;
    
    if (proto == IPPROTO_UDP) {
        if (dst_port == 5001) {
            result = udp1_class;
            printf("Port 5001 → udp1 (class %u)\n", result->class_id);
        }
        else if (dst_port == 6001) {
            result = udp2_class;
            printf("Port 6001 → udp2 (class %u)\n", result->class_id);
        }
    }
    
    if (result == NULL) {
        printf("WARNING: Unclassified packet, port %u, proto %u\n", 
               dst_port, proto);
        result = default_class;
    }
    
    return result;
}
EOF
    echo ""
    exit 0
fi

if [ "$answer4" = "a" ] || [ "$answer4" = "b" ]; then
    echo ""
    echo "✓ Both classes are receiving packets (good!)"
    echo ""
    echo "Issue: One class is hitting queue limit and dropping."
    echo "This is the RT heap starvation bug."
    echo ""
fi

echo ""
echo "=========================================================================="
echo "ROOT CAUSE ANALYSIS"
echo "=========================================================================="
echo ""
echo "Based on 'sometimes udp1, sometimes udp2 wins':"
echo ""
echo "The issue is a RACE CONDITION + PARENT USC BUG:"
echo ""
echo "1. Both udp1 and udp2 have identical RSC curves"
echo "2. When packets arrive at similar times, they have identical deadlines"
echo "3. RT heap returns ONE of them (deterministic based on heap order)"
echo "4. That class gets serviced → its parent (site1 or site2) updates cl_myf"
echo "5. Parent's cl_myf advances, potentially blocking OTHER children"
echo "6. The 'loser' class never gets scheduled → queue fills → drops"
echo ""
echo "WHY 'sometimes different class wins':"
echo "  - Depends on which iperf3 you start first"
echo "  - First one to enqueue packets becomes active first"
echo "  - Heap insertion order affects which one is at heap[0]"
echo ""
echo "=========================================================================="
echo "THE FIX"
echo "=========================================================================="
echo ""
echo "There are TWO bugs to fix:"
echo ""
echo "BUG #1: RT heap always returns same class for identical deadlines"
echo "FIX: Already implemented in hfsc_production_v1.1_FIXED.tar.gz"
echo "     (Round-robin among classes with same deadline)"
echo ""
echo "BUG #2: Parent USC blocking is too aggressive (if both under same parent)"
echo ""
echo "Actually, wait... let me check something:"
echo ""
read -p "When you test, do you start BOTH iperf3 at THE SAME TIME? (yes/no): " answer5

if [ "$answer5" = "yes" ]; then
    echo ""
    echo "OK, so both classes become active simultaneously."
    echo "The issue is definitely RT heap starvation."
    echo ""
else
    echo ""
    echo "AH! You start them at DIFFERENT times!"
    echo ""
    echo "This means:"
    echo "  1. First iperf3 starts → udp1 becomes active"
    echo "  2. udp1 processes packets, its queue works fine"
    echo "  3. Second iperf3 starts → udp2 becomes active"
    echo "  4. Now BOTH are competing for RT heap selection"
    echo "  5. But they have IDENTICAL deadlines!"
    echo "  6. Heap returns the one that was inserted first (udp1)"
    echo "  7. udp2 never gets selected → queue fills → drops"
    echo ""
fi

echo ""
echo "=========================================================================="
echo "IMMEDIATE FIX TO TEST"
echo "=========================================================================="
echo ""
echo "Option 1: Use the fixed v1.1 code (has round-robin in RT selection)"
echo ""
echo "Option 2: Make RSC curves slightly different:"
echo ""
cat << 'EOF'
/* In hfsc_example.c, setup_hfsc_hierarchy(): */

/* UDP1: 10ms delay */
udp1_class = hfsc_create_class(sched, site1_class, 11, true,
    &(hfsc_service_curve_t){
        .m1 = 5000000,   
        .d = 10000,      // 10ms
        .m2 = 1250000    
    },
    &(hfsc_service_curve_t){1250000, 0, 1250000},
    &(hfsc_service_curve_t){2000000, 0, 2000000}
);

/* UDP2: 12ms delay (DIFFERENT!) */
udp2_class = hfsc_create_class(sched, site2_class, 21, true,
    &(hfsc_service_curve_t){
        .m1 = 5000000,   
        .d = 12000,      // 12ms - THIS IS THE KEY CHANGE
        .m2 = 1250000    
    },
    &(hfsc_service_curve_t){1250000, 0, 1250000},
    &(hfsc_service_curve_t){2000000, 0, 2000000}
);
EOF

echo ""
echo "This creates different deadlines → both classes get selected fairly."
echo ""
echo "=========================================================================="

