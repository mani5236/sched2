#!/bin/bash
#############################################################################
# HFSC Network Accelerator - Deployment Configuration Script
#
# This script automates the deployment of HFSC scheduler on a network
# accelerator device. It handles system configuration, DPDK setup,
# and application deployment.
#############################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
HFSC_HOME="/opt/hfsc"
HUGEPAGE_SIZE="2048"  # 2MB
HUGEPAGE_COUNT="1024" # 2GB total
DPDK_VERSION="23.11"
CPU_CORES="1-3"       # Cores to isolate for DPDK

# Functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_error "Please run as root"
        exit 1
    fi
}

check_cpu() {
    log_info "Checking CPU capabilities..."
    
    if ! grep -q sse4_2 /proc/cpuinfo; then
        log_error "CPU does not support SSE4.2"
        exit 1
    fi
    
    cores=$(nproc)
    log_info "Found $cores CPU cores"
    
    if [ "$cores" -lt 4 ]; then
        log_warn "Recommended minimum 4 CPU cores"
    fi
}

setup_hugepages() {
    log_info "Configuring hugepages..."
    
    # Check if already configured
    current=$(cat /sys/kernel/mm/hugepages/hugepages-${HUGEPAGE_SIZE}kB/nr_hugepages)
    if [ "$current" -ge "$HUGEPAGE_COUNT" ]; then
        log_info "Hugepages already configured ($current pages)"
        return
    fi
    
    # Configure hugepages
    echo $HUGEPAGE_COUNT > /sys/kernel/mm/hugepages/hugepages-${HUGEPAGE_SIZE}kB/nr_hugepages
    
    # Verify
    actual=$(cat /sys/kernel/mm/hugepages/hugepages-${HUGEPAGE_SIZE}kB/nr_hugepages)
    if [ "$actual" -lt "$HUGEPAGE_COUNT" ]; then
        log_error "Failed to allocate hugepages (got $actual, wanted $HUGEPAGE_COUNT)"
        exit 1
    fi
    
    # Mount hugepages
    if ! mountpoint -q /mnt/huge; then
        mkdir -p /mnt/huge
        mount -t hugetlbfs nodev /mnt/huge
        log_info "Mounted hugepages at /mnt/huge"
    fi
    
    # Make persistent
    if ! grep -q "/mnt/huge" /etc/fstab; then
        echo "nodev /mnt/huge hugetlbfs defaults 0 0" >> /etc/fstab
        log_info "Added hugepages to /etc/fstab"
    fi
}

configure_grub() {
    log_info "Configuring GRUB for CPU isolation..."
    
    GRUB_FILE="/etc/default/grub"
    GRUB_PARAMS="isolcpus=$CPU_CORES nohz_full=$CPU_CORES rcu_nocbs=$CPU_CORES default_hugepagesz=2M hugepagesz=2M hugepages=$HUGEPAGE_COUNT"
    
    # Check if already configured
    if grep -q "isolcpus=$CPU_CORES" $GRUB_FILE; then
        log_info "GRUB already configured"
        return
    fi
    
    # Backup
    cp $GRUB_FILE ${GRUB_FILE}.backup
    
    # Add parameters
    if grep -q "^GRUB_CMDLINE_LINUX=" $GRUB_FILE; then
        sed -i "s/^GRUB_CMDLINE_LINUX=\"/GRUB_CMDLINE_LINUX=\"$GRUB_PARAMS /" $GRUB_FILE
    else
        echo "GRUB_CMDLINE_LINUX=\"$GRUB_PARAMS\"" >> $GRUB_FILE
    fi
    
    # Update GRUB
    if [ -f /usr/sbin/update-grub ]; then
        update-grub
    elif [ -f /usr/sbin/grub2-mkconfig ]; then
        grub2-mkconfig -o /boot/grub2/grub.cfg
    else
        log_warn "Could not update GRUB - please update manually"
        return
    fi
    
    log_warn "GRUB updated - reboot required for changes to take effect"
}

setup_cpu_governor() {
    log_info "Setting CPU governor to performance..."
    
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        if [ -f "$cpu" ]; then
            echo performance > $cpu
        fi
    done
    
    # Make persistent
    cat > /etc/systemd/system/cpu-performance.service <<EOF
[Unit]
Description=Set CPU governor to performance

[Service]
Type=oneshot
ExecStart=/bin/bash -c 'for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo performance > \$cpu; done'

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable cpu-performance.service
    log_info "CPU governor service enabled"
}

install_dpdk() {
    log_info "Checking DPDK installation..."
    
    if pkg-config --exists libdpdk; then
        version=$(pkg-config --modversion libdpdk)
        log_info "DPDK $version is already installed"
        return
    fi
    
    log_info "Installing DPDK..."
    
    # Try package manager first
    if command -v apt-get &> /dev/null; then
        apt-get update
        apt-get install -y dpdk dpdk-dev libdpdk-dev || log_warn "Package install failed, will build from source"
    fi
    
    # Check again
    if pkg-config --exists libdpdk; then
        return
    fi
    
    # Build from source
    log_info "Building DPDK from source..."
    
    cd /tmp
    wget https://fast.dpdk.org/rel/dpdk-${DPDK_VERSION}.tar.xz
    tar xf dpdk-${DPDK_VERSION}.tar.xz
    cd dpdk-${DPDK_VERSION}
    
    apt-get install -y python3-pip python3-pyelftools
    pip3 install meson ninja
    
    meson setup build
    cd build
    ninja
    ninja install
    ldconfig
    
    log_info "DPDK installed from source"
}

bind_nics() {
    log_info "Configuring NICs for DPDK..."
    
    # Load drivers
    modprobe vfio-pci || log_warn "Failed to load vfio-pci"
    modprobe uio || log_warn "Failed to load uio"
    
    # Check for dpdk-devbind
    if ! command -v dpdk-devbind.py &> /dev/null; then
        log_warn "dpdk-devbind.py not found - skipping NIC binding"
        log_info "Manually bind NICs with: dpdk-devbind.py --bind=vfio-pci <PCI_ADDRESS>"
        return
    fi
    
    # Show status
    log_info "Current NIC status:"
    dpdk-devbind.py --status
    
    log_warn "Please manually bind NICs using:"
    log_info "  dpdk-devbind.py --bind=vfio-pci <PCI_ADDRESS>"
}

build_hfsc() {
    log_info "Building HFSC scheduler..."
    
    cd $HFSC_HOME
    
    # Build with Meson
    if [ -d builddir ]; then
        log_info "Cleaning previous build..."
        rm -rf builddir
    fi
    
    meson setup builddir
    cd builddir
    ninja
    
    log_info "HFSC built successfully"
}

install_service() {
    log_info "Installing systemd service..."
    
    cat > /etc/systemd/system/hfsc-accelerator.service <<EOF
[Unit]
Description=HFSC Network Accelerator
After=network.target

[Service]
Type=simple
ExecStart=$HFSC_HOME/builddir/hfsc_accelerator -l $CPU_CORES -n 4 --file-prefix hfsc --
Restart=always
RestartSec=10
User=root
LimitMEMLOCK=infinity
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    log_info "Systemd service installed (not enabled)"
    log_info "To enable: systemctl enable hfsc-accelerator"
    log_info "To start:  systemctl start hfsc-accelerator"
}

create_config() {
    log_info "Creating default configuration..."
    
    cat > $HFSC_HOME/hfsc.conf <<EOF
# HFSC Scheduler Configuration
# This file documents the hierarchy configuration
# Actual configuration is in hfsc_example.c

[root]
bandwidth = 100 Mbps

[site1]
parent = root
bandwidth = 50 Mbps
max_bandwidth = 60 Mbps

[site1.udp]
bandwidth = 10 Mbps
delay = 10 ms
max_bandwidth = 16 Mbps
type = real-time

[site1.tcp]
bandwidth = 40 Mbps
max_bandwidth = 48 Mbps
type = bulk

[site2]
parent = root
bandwidth = 50 Mbps
max_bandwidth = 60 Mbps

[site2.udp]
bandwidth = 10 Mbps
delay = 10 ms
max_bandwidth = 16 Mbps
type = real-time

[site2.tcp]
bandwidth = 40 Mbps
max_bandwidth = 48 Mbps
type = bulk

[default]
parent = root
bandwidth = 800 Kbps
type = best-effort
EOF
    
    log_info "Configuration saved to $HFSC_HOME/hfsc.conf"
}

verify_installation() {
    log_info "Verifying installation..."
    
    # Check binary
    if [ ! -f $HFSC_HOME/builddir/hfsc_accelerator ]; then
        log_error "HFSC binary not found"
        exit 1
    fi
    
    # Check hugepages
    free_pages=$(cat /sys/kernel/mm/hugepages/hugepages-${HUGEPAGE_SIZE}kB/free_hugepages)
    if [ "$free_pages" -lt 512 ]; then
        log_warn "Low free hugepages ($free_pages)"
    fi
    
    # Check DPDK
    if ! pkg-config --exists libdpdk; then
        log_error "DPDK not properly installed"
        exit 1
    fi
    
    log_info "Installation verified successfully"
}

print_summary() {
    echo ""
    echo "======================================================================"
    echo "  HFSC Network Accelerator - Installation Complete"
    echo "======================================================================"
    echo ""
    echo "Installation directory: $HFSC_HOME"
    echo "Binary: $HFSC_HOME/builddir/hfsc_accelerator"
    echo ""
    echo "Next steps:"
    echo "  1. Bind NICs to DPDK:"
    echo "     dpdk-devbind.py --bind=vfio-pci <PCI_ADDRESS>"
    echo ""
    echo "  2. Test manually:"
    echo "     cd $HFSC_HOME"
    echo "     sudo ./builddir/hfsc_accelerator -l $CPU_CORES -n 4 --"
    echo ""
    echo "  3. Install as service:"
    echo "     systemctl enable hfsc-accelerator"
    echo "     systemctl start hfsc-accelerator"
    echo ""
    echo "  4. Monitor logs:"
    echo "     journalctl -u hfsc-accelerator -f"
    echo ""
    echo "Configuration file: $HFSC_HOME/hfsc.conf"
    echo ""
    echo "For more information, see: $HFSC_HOME/README.md"
    echo "======================================================================"
}

# Main deployment flow
main() {
    log_info "Starting HFSC deployment..."
    
    check_root
    check_cpu
    
    # System configuration
    setup_hugepages
    configure_grub
    setup_cpu_governor
    
    # DPDK installation
    install_dpdk
    bind_nics
    
    # HFSC installation
    mkdir -p $HFSC_HOME
    cd $HFSC_HOME
    
    build_hfsc
    install_service
    create_config
    
    # Verification
    verify_installation
    print_summary
    
    log_info "Deployment complete!"
}

# Run main
main "$@"
