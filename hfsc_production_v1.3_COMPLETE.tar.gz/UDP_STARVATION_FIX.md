# Testing Guide: UDP Starvation Issue (udp1 + udp2)

## Problem Description

When sending traffic to both UDP classes with **identical RSC curves**:
- **Expected**: 32 Mbps total (16 Mbps × 2)
- **Actual**: 16 Mbps total, one class drops packets
- **Symptom**: "Sometimes udp1 gets, sometimes udp2 gets"

## Root Cause

**RT Heap Determinism**: When two classes have identical deadlines, the min-heap always returns the same one (deterministic tie-breaking). The "loser" class never gets selected, its queue fills up, and packets drop.

**Why "sometimes different winner"**: Whichever class becomes active FIRST (enqueues packets first) gets inserted into the heap first and wins the tie-break.

## The Fix (Already in v1.1)

The v1.1 code includes **round-robin tie-breaking** in `hfsc_select_rt()`:

```c
/* When multiple classes have same deadline, rotate among them */
static uint32_t rr_counter = 0;
uint32_t idx = (rr_counter++) % num_candidates;
return candidates[idx];
```

This ensures **fair selection** among classes with identical deadlines.

## Testing Steps

### Test 1: Reproduce the Issue (v1.0 code)

If you still have v1.0:

```bash
# Terminal 1: UDP to port 5001 (udp1)
iperf3 -c 192.168.2.30 -u -b 20M -p 5001 -t 60

# Terminal 2: UDP to port 6001 (udp2)  
iperf3 -c 192.168.2.30 -u -b 20M -p 6001 -t 60
```

**Expected bug behavior**:
- Total throughput: ~16 Mbps (not 32 Mbps)
- Statistics show one class has high drops
- One class has 0 or very few packets

### Test 2: Verify Fix (v1.1 code)

Use the fixed code:

```bash
# Same test as above
# Terminal 1:
iperf3 -c 192.168.2.30 -u -b 20M -p 5001 -t 60

# Terminal 2:
iperf3 -c 192.168.2.30 -u -b 20M -p 6001 -t 60
```

**Expected fixed behavior**:
- Total throughput: ~32 Mbps (both classes working)
- Each class gets ~16 Mbps (their USC limit)
- Minimal drops (only if you exceed 16 Mbps per class)
- Statistics show both classes have similar packet counts

### Test 3: Verify Round-Robin is Working

Add debug output to confirm:

```c
// In hfsc_scheduler.c, hfsc_select_rt(), after selecting from candidates:

if (num_candidates > 1) {
    static uint32_t rr_counter = 0;
    uint32_t idx = (rr_counter++) % num_candidates;
    
    // DEBUG OUTPUT
    static uint64_t select_count = 0;
    if (select_count++ % 1000 == 0) {
        printf("RT: %d candidates, selected idx=%u (class %u)\n",
               num_candidates, idx, candidates[idx]->class_id);
    }
    
    return candidates[idx];
}
```

You should see:
```
RT: 2 candidates, selected idx=0 (class 11)
RT: 2 candidates, selected idx=1 (class 21)
RT: 2 candidates, selected idx=0 (class 11)
RT: 2 candidates, selected idx=1 (class 21)
...
```

This confirms both classes (11=udp1, 21=udp2) are being selected alternately.

## Alternative Workaround (if you can't use v1.1)

If you're stuck with v1.0 code, make the RSC curves **slightly different**:

### Option A: Different Delays

```c
/* In hfsc_example.c */

// UDP1: 10ms delay
udp1_class = hfsc_create_class(...,
    &(hfsc_service_curve_t){5000000, 10000, 1250000},  // RSC
    ...
);

// UDP2: 11ms delay (1ms difference is enough!)
udp2_class = hfsc_create_class(...,
    &(hfsc_service_curve_t){5000000, 11000, 1250000},  // RSC
    ...
);
```

### Option B: Different Initial Rates

```c
// UDP1: 40 Mbps initial
udp1_class = hfsc_create_class(...,
    &(hfsc_service_curve_t){5000000, 10000, 1250000},  // RSC
    ...
);

// UDP2: 38 Mbps initial (slightly different)
udp2_class = hfsc_create_class(...,
    &(hfsc_service_curve_t){4750000, 10000, 1250000},  // RSC
    ...
);
```

## Diagnostic Commands

### Check which class is active:

```bash
# Add to hfsc_dump_state() or check statistics:
UDP1 (Real-time): TX: 0 pkts (0 MB), Drops: 125043      # ← STARVED
TCP1 (Bulk):      TX: 892341 pkts (1285 MB), Drops: 0
UDP2 (Real-time): TX: 125043 pkts (180 MB), Drops: 0   # ← WINNER
TCP2 (Bulk):      TX: 891203 pkts (1283 MB), Drops: 0
```

If you see this pattern (one UDP has 0 packets, other has drops), you have the starvation bug.

### Check queue lengths:

```bash
# In hfsc_dequeue(), add:
if (cl->class_id == 11 || cl->class_id == 21) {  // UDP classes
    static uint64_t count = 0;
    if (count++ % 1000 == 0) {
        printf("Class %u: qlen=%u, active=%d, cl_e=%lu, cl_d=%lu\n",
               cl->class_id, cl->qlen, cl->state, cl->cl_e, cl->cl_d);
    }
}
```

Starved class will show: `qlen=8192` (queue full, packets dropping)

## Expected Performance (with fix)

### Both UDP Classes Active:

| Class | Bandwidth | Delay | Drops |
|-------|-----------|-------|-------|
| udp1  | 16 Mbps   | <12ms | minimal |
| udp2  | 16 Mbps   | <12ms | minimal |
| **Total** | **32 Mbps** | - | - |

### Notes:

- Each class hits its USC limit (16 Mbps)
- Both classes share RT criterion fairly (round-robin)
- Delay stays under RSC target + 2ms margin
- Drops only if you send >16 Mbps per class

## Troubleshooting

### Still seeing starvation?

1. **Verify v1.1 code**: Check that `hfsc_select_rt()` has the round-robin logic
2. **Check hierarchy**: Ensure udp1 and udp2 are under different parents (site1 vs site2)
3. **Verify USC**: Each parent should have USC > 16 Mbps
4. **Check classification**: Add debug to confirm packets go to correct class

### Getting less than 32 Mbps total?

1. **Parent USC limiting**: Check if site1/site2 USC is blocking
2. **Link capacity**: Ensure physical link > 32 Mbps
3. **CPU bottleneck**: Check if HFSC is CPU-bound
4. **Network congestion**: Test with iperf3 without HFSC first

### One class still dropping?

1. **Queue size**: Increase `HFSC_QUEUE_SIZE` if needed
2. **Rate limiting**: Check you're not sending >16 Mbps to one class
3. **USC enforcement**: Verify USC is set correctly (2000000 = 16 Mbps)

## Summary

**The v1.1 code FIXES this issue** with round-robin tie-breaking.

If you're seeing the problem with v1.1:
1. Verify you're actually running v1.1 code
2. Check that both iperf3 instances are running
3. Verify classification logic routes packets correctly
4. Add debug output to confirm round-robin is working

The fix ensures **fair scheduling** among classes with identical service curves, preventing the starvation that causes "sometimes udp1, sometimes udp2" behavior.
