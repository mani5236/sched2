#!/usr/bin/env python3
"""
HFSC UDP Traffic Issue Diagnostic Tool

Helps diagnose why (udp1, udp2) pair only achieves 16 Mbps instead of 32 Mbps
"""

import sys

print("=" * 70)
print("HFSC UDP Traffic Diagnostic")
print("=" * 70)
print()

# The hierarchy from hfsc_example.c
hierarchy = """
root (100 Mbps, max 100 Mbps)
├─ site1 (50 Mbps, max 60 Mbps)
│   ├─ udp1 (10 Mbps RSC, max 16 Mbps USC)
│   │    RSC: 40 Mbps for 10ms → 10 Mbps
│   │    FSC: 10 Mbps
│   │    USC: 16 Mbps MAX
│   └─ tcp1 (40 Mbps, max 48 Mbps)
├─ site2 (50 Mbps, max 60 Mbps)
│   ├─ udp2 (10 Mbps RSC, max 16 Mbps USC)
│   │    RSC: 40 Mbps for 10ms → 10 Mbps
│   │    FSC: 10 Mbps
│   │    USC: 16 Mbps MAX
│   └─ tcp2 (40 Mbps, max 48 Mbps)
└─ default (800 Kbps min)
"""

print("Current Hierarchy:")
print(hierarchy)
print()

# Possible issues
print("DIAGNOSTIC QUESTIONS:")
print()

print("Q1: Are you sending traffic to BOTH port 5001 AND 6001?")
print("    OR just one port to test both classes?")
print()
response = input("    Your answer (both/one): ").strip().lower()

if response == "one":
    print()
    print("⚠️  ISSUE IDENTIFIED:")
    print("    You're sending all traffic to ONE port, which means:")
    print("    - Classification returns ONE class for all packets")
    print("    - That single class is limited by its USC (16 Mbps)")
    print("    - The other class receives NO traffic")
    print()
    print("FIX: Send traffic to BOTH ports:")
    print("    Terminal 1: iperf3 -c <ip> -u -b 20M -p 5001")
    print("    Terminal 2: iperf3 -c <ip> -u -b 20M -p 6001")
    sys.exit(0)

print()
print("Q2: When you modified classify_packet(), what did you return?")
print("    a) Return udp1_class for port 5001, udp2_class for port 6001")
print("    b) Return SAME class for both ports")
print()
response = input("    Your answer (a/b): ").strip().lower()

if response == "b":
    print()
    print("⚠️  ISSUE IDENTIFIED:")
    print("    You're returning the SAME class for different ports!")
    print("    This means all traffic goes to ONE class (16 Mbps USC limit)")
    print()
    print("FIX: Different ports should return different classes:")
    print()
    print("    if (dst_port == 5001)")
    print("        return udp1_class;  // Under site1")
    print("    else if (dst_port == 6001)")
    print("        return udp2_class;  // Under site2")
    sys.exit(0)

print()
print("Q3: Are BOTH classes receiving packets?")
print()
response = input("    Your answer (yes/no): ").strip().lower()

if response == "no":
    print()
    print("⚠️  ISSUE IDENTIFIED:")
    print("    Only ONE class is receiving packets!")
    print()
    print("    Possible causes:")
    print("    1. Classification logic returns same class for both ports")
    print("    2. Only sending to one port")
    print("    3. Network routing sends all traffic same way")
    print()
    print("    Check classification with debug output:")
    print()
    print("    hfsc_class_t *classify_packet(struct rte_mbuf *m) {")
    print("        // ... existing code ...")
    print("        ")
    print("        hfsc_class_t *result;")
    print("        if (dst_port == 5001)")
    print("            result = udp1_class;")
    print("        else if (dst_port == 6001)")
    print("            result = udp2_class;")
    print("        ")
    print("        // DEBUG OUTPUT")
    print("        static uint64_t count = 0;")
    print("        if (count++ % 1000 == 0) {")
    print("            printf(\"Port %u -> Class %u\\n\", dst_port, result->class_id);")
    print("        }")
    print("        return result;")
    print("    }")
    sys.exit(0)

print()
print("Q4: What's the total throughput you're seeing?")
print()
throughput = input("    Total Mbps: ").strip()

try:
    mbps = float(throughput)
except:
    print("Invalid number")
    sys.exit(1)

print()
if mbps < 18:
    print("⚠️  LIKELY ISSUE: RT Heap Starvation")
    print()
    print("    When both UDP classes have identical RSC curves:")
    print("    - Both become eligible at same time")
    print("    - Both have similar deadlines")
    print("    - RT heap selects one consistently (tie-breaking)")
    print("    - Selected class hits USC limit (16 Mbps)")
    print("    - Other class STARVES because it's never selected!")
    print()
    print("    This is a KNOWN HFSC limitation with identical RT curves.")
    print()
    print("=" * 70)
    print("FIXES:")
    print("=" * 70)
    print()
    print("FIX #1: Slightly Different RSC Curves")
    print("    Make the curves slightly different so tie-breaking is fair:")
    print()
    print("    udp1: RSC = {5000000, 10000, 1250000}  // 10ms delay")
    print("    udp2: RSC = {5000000, 11000, 1250000}  // 11ms delay")
    print()
    print("FIX #2: Different Initial Rates")
    print()
    print("    udp1: RSC = {5000000, 10000, 1250000}  // 40 Mbps initial")
    print("    udp2: RSC = {4500000, 10000, 1250000}  // 36 Mbps initial")
    print()
    print("FIX #3: Use LS Criterion Instead")
    print("    Remove RSC from both classes, use only FSC:")
    print()
    print("    udp1: RSC = NULL")
    print("          FSC = {5000000, 10000, 1250000}  // Delay in FSC")
    print("          USC = {2000000, 0, 2000000}")
    print()
    print("    This uses link-sharing criterion which has better fairness.")
    print()
    print("FIX #4: Increase Parent USC")
    print("    If both under site1:")
    print("    site1 USC = 60 Mbps (currently)")
    print()
    print("    But wait... they're under DIFFERENT parents (site1 & site2)")
    print("    Each parent has 60 Mbps USC, so 32 Mbps total SHOULD work.")
    print()
    
elif mbps < 25:
    print("⚠️  PARTIAL SUCCESS")
    print()
    print("    Getting ~20 Mbps suggests both classes are working")
    print("    but not achieving full USC limits.")
    print()
    print("    Possible causes:")
    print("    1. Parent USC limiting (site1 or site2 max 60 Mbps)")
    print("    2. Network congestion")
    print("    3. RT criterion selecting one class more often")
    print()
    
else:
    print("✓  WORKING AS EXPECTED")
    print()
    print("    Both UDP classes are getting bandwidth!")
    print("    Total close to 32 Mbps (2 × 16 Mbps USC)")

print()
print("=" * 70)
print("RECOMMENDED TESTING")
print("=" * 70)
print()
print("1. Add debug output to classify_packet():")
print("   - Print which class is selected for each port")
print("   - Count packets per class")
print()
print("2. Check statistics:")
print("   - Are drops happening?")
print("   - Which class has drops?")
print()
print("3. Monitor with hfsc_dump_state()")
print("   - Check qlen for each class")
print("   - Verify both are active")
print()
print("4. Try the FIX #1 (slightly different delays)")
print()
