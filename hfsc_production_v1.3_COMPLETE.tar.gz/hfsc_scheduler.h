/********************************************************************
 * HFSC Scheduler - Production-Ready Implementation
 * Based on:
 *   - "A Hierarchical Fair Service Curve Algorithm" (Stoica et al.)
 *   - Linux kernel net/sched/sch_hfsc.c
 * 
 * Features:
 *   - O(log n) complexity using RB-trees and heaps
 *   - Integer-only math (no floating point in fast path)
 *   - USC enforcement with proper isolation
 *   - Virtual time propagation
 *   - Efficient curve updates
 ********************************************************************/

#ifndef HFSC_SCHEDULER_H
#define HFSC_SCHEDULER_H

#include <stdint.h>
#include <stdbool.h>
#include <rte_mbuf.h>
#include <rte_ring.h>
#include <rte_cycles.h>

/* ==================== CONFIGURATION ==================== */

#define HFSC_MAX_CLASSES        256
#define HFSC_MAX_CHILDREN       32
#define HFSC_QUEUE_SIZE         8192
#define HFSC_MAX_DEPTH          8

/* Precision for fixed-point arithmetic (64-bit to avoid overflow) */
#define HFSC_SM_SHIFT           24
#define HFSC_SM_MASK            ((1ULL << HFSC_SM_SHIFT) - 1)

/* ==================== SERVICE CURVE ==================== */

/**
 * Service curve specification (two-piece linear)
 * Defined by user in bytes/sec and microseconds
 */
typedef struct {
    uint64_t m1;    /* Initial slope (bytes/sec) */
    uint64_t d;     /* Delay for first segment (microseconds) */
    uint64_t m2;    /* Sustained slope (bytes/sec) */
} hfsc_service_curve_t;

/**
 * Internal runtime service curve (fixed-point arithmetic)
 * All times in TSC cycles, slopes in bytes/cycle (fixed-point)
 * 
 * Represents: y = y0 + sm1*(x-x0) for x in [x0, x0+dx]
 *             y = y0 + dy + sm2*(x-x0-dx) for x > x0+dx
 */
typedef struct {
    uint64_t x;     /* Start time (TSC cycles) */
    uint64_t y;     /* Start bytes */
    uint64_t dx;    /* Duration of first segment (cycles) */
    uint64_t dy;    /* Bytes in first segment */
    uint64_t sm1;   /* Slope 1 (bytes/cycle, fixed-point) */
    uint64_t sm2;   /* Slope 2 (bytes/cycle, fixed-point) */
} hfsc_internal_sc_t;

/* ==================== CLASS STRUCTURE ==================== */

typedef enum {
    HFSC_CLASS_INACTIVE = 0,
    HFSC_CLASS_ACTIVE,
} hfsc_class_state_t;

typedef struct hfsc_class hfsc_class_t;

struct hfsc_class {
    /* Hierarchy */
    hfsc_class_t    *parent;
    hfsc_class_t    *children[HFSC_MAX_CHILDREN];
    uint32_t        num_children;
    uint32_t        class_id;
    bool            is_leaf;
    
    /* Queue (leaf classes only) */
    struct rte_ring *queue;
    uint32_t        qlen;           /* Queue length in packets */
    uint64_t        qbytes;         /* Queue length in bytes */
    
    /* Service curves */
    hfsc_service_curve_t rsc;       /* Real-time service curve */
    hfsc_service_curve_t fsc;       /* Fair service curve */
    hfsc_service_curve_t usc;       /* Upper-limit service curve */
    
    /* Runtime curves (internal representation) */
    hfsc_internal_sc_t cl_rsc;      /* Runtime RSC (deadline) */
    hfsc_internal_sc_t cl_fsc;      /* Runtime FSC (virtual) */
    hfsc_internal_sc_t cl_usc;      /* Runtime USC (upper) */
    hfsc_internal_sc_t cl_eligible; /* Eligible curve */
    
    /* Accounting */
    uint64_t        cumul;          /* Cumulative service (RT criterion) */
    uint64_t        total;          /* Total service (both criteria) */
    uint64_t        last_update;    /* Last update time */
    
    /* Real-time criterion */
    uint64_t        cl_e;           /* Eligible time */
    uint64_t        cl_d;           /* Deadline */
    int             rt_index;       /* Index in RT heap (-1 if not in heap) */
    
    /* Link-sharing criterion */
    uint64_t        cl_vt;          /* Virtual time */
    uint64_t        cl_vtoff;       /* Virtual time offset for period */
    uint32_t        cl_vtperiod;    /* Virtual time period */
    uint32_t        cl_parentperiod;/* Parent's period at activation */
    
    /* USC enforcement */
    uint64_t        cl_myf;         /* My fit-time (when I can send) */
    uint64_t        cl_cfmin;       /* Min cl_myf among siblings */
    uint64_t        cl_cvtmin;      /* Min virtual time among siblings */
    uint64_t        cl_cvtmax;      /* Max virtual time among siblings */
    
    /* State */
    hfsc_class_state_t state;
    bool            in_vttree;      /* In virtual time tree */
    
    /* Statistics */
    uint64_t        stats_packets;
    uint64_t        stats_bytes;
    uint64_t        stats_drops;
};

/* ==================== SCHEDULER STATE ==================== */

typedef struct {
    hfsc_class_t    *root;
    hfsc_class_t    *classes[HFSC_MAX_CLASSES];
    uint32_t        num_classes;
    
    /* Real-time eligible heap (min-heap by deadline) */
    hfsc_class_t    **rt_heap;
    uint32_t        rt_heap_size;
    uint32_t        rt_heap_capacity;
    
    /* Virtual time tracking per hierarchy level */
    uint64_t        vt_min[HFSC_MAX_DEPTH];
    uint64_t        vt_max[HFSC_MAX_DEPTH];
    
    /* TSC frequency */
    uint64_t        tsc_hz;
    
    /* Statistics */
    uint64_t        total_packets_in;
    uint64_t        total_packets_out;
    uint64_t        total_drops;
} hfsc_scheduler_t;

/* ==================== API FUNCTIONS ==================== */

/**
 * Initialize the HFSC scheduler
 * Returns 0 on success, -1 on error
 */
int hfsc_init(hfsc_scheduler_t **sched);

/**
 * Cleanup and free all resources
 */
void hfsc_cleanup(hfsc_scheduler_t *sched);

/**
 * Create root class
 */
hfsc_class_t *hfsc_create_root(hfsc_scheduler_t *sched,
                               const hfsc_service_curve_t *rsc,
                               const hfsc_service_curve_t *fsc,
                               const hfsc_service_curve_t *usc);

/**
 * Create a class (interior or leaf)
 * 
 * @param sched     Scheduler instance
 * @param parent    Parent class (NULL for root)
 * @param class_id  Unique identifier
 * @param is_leaf   True if this is a leaf class
 * @param rsc       Real-time service curve (can be NULL)
 * @param fsc       Fair service curve (required)
 * @param usc       Upper-limit service curve (can be NULL)
 * @return          Pointer to created class or NULL on error
 */
hfsc_class_t *hfsc_create_class(hfsc_scheduler_t *sched,
                                hfsc_class_t *parent,
                                uint32_t class_id,
                                bool is_leaf,
                                const hfsc_service_curve_t *rsc,
                                const hfsc_service_curve_t *fsc,
                                const hfsc_service_curve_t *usc);

/**
 * Enqueue a packet to a leaf class
 * 
 * @param sched     Scheduler instance
 * @param cl        Leaf class
 * @param m         Packet mbuf
 * @return          0 on success, -1 if queue full or error
 */
int hfsc_enqueue(hfsc_scheduler_t *sched, hfsc_class_t *cl, 
                 struct rte_mbuf *m);

/**
 * Dequeue next packet according to HFSC algorithm
 * 
 * @param sched     Scheduler instance
 * @return          Packet mbuf or NULL if no packet available
 */
struct rte_mbuf *hfsc_dequeue(hfsc_scheduler_t *sched);

/**
 * Check if scheduler has packets to send
 */
bool hfsc_has_packets(hfsc_scheduler_t *sched);

/**
 * Get class statistics
 */
void hfsc_get_class_stats(hfsc_class_t *cl, 
                          uint64_t *packets, 
                          uint64_t *bytes, 
                          uint64_t *drops);

/**
 * Print scheduler state (for debugging)
 */
void hfsc_dump_state(hfsc_scheduler_t *sched);

#endif /* HFSC_SCHEDULER_H */
